# OSDMP template

Created by Marshall J. Styczinski based on a Word template created by Marshall J. Styczinski, Daniel Crichton, Joseph Spahr, Samantha Ozyildirim, Rolf Danner, and the JPL SPD-41a team.
LaTeX template currently maintained by Shawn Brooks. 

Questions/comments: shawn.m.brooks@jpl.nasa.gov

## Instructions

OSDMP.tex is intended to be imported into a larger document using the \input{} command.
See example.tex for a demonstration.

Plain text in OSDMP.tex covers a hypothetical example.
Edit this text to fit your proposal project.

## Guidance text

OSDMP.tex imports text instructions that describe general requirements for OSDMPs.
Review the blue instructions and red comments before removing them.
Instructions can be hidden by commenting out the relevant \input{} commands in OSDMP.tex.
